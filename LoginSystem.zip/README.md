# Login System Project

## Student Details
Name: Your Name  
Student Number: Your Student Number  

## Description
Java-based registration and login system with validation and unit testing.

## Features
- Username validation
- Password complexity validation
- South African phone validation (+27)
- Registration & login
- JUnit tests

## How to Run
Open in NetBeans and run Main.java
